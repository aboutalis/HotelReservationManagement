package db2021;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.LinkedList;
import tuc.ece.cs102.util.StandardInputRead;

public class database {
private static Connection conn;
	
	public database() {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Found!");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
			System.out.println("Driver Not Found! Please check the build path...");
		}
	}
	
	public boolean establishConnection(String ip, String dbName, String user, String passw) {
		try {
			//("jdbc:postgresql://localhost:5432", "db2021", "postgres", "61445239t")
			conn	=	DriverManager.getConnection("jdbc:postgresql://"+ip+":5432/"+dbName, user, passw);
			System.out.println("\n\n********************* \nConnection established \n*********************");
			return true;
		} catch (SQLException e) {
			return false;
		}
	}
	
	public void CommitOnRequest() {
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Savepoint addSavepoint() {
		try {
			return conn.setSavepoint();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}	
	//---------------------------------------------------------------------------------------
	//---------------------- Try to find hotels using a specifc prefix ----------------------
	//---------------------------------------------------------------------------------------
	public ResultSet findHotelByPrefix(String prefix) {
		try {												
			PreparedStatement pst = conn.prepareStatement(
					"select h.name "
					+ "from hotel h "
					+ "where left(h.name,1) = ? "
					+ "order by h.name",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			// set the parameters
			pst.setString(1, prefix);
			
			// execute query and print results
			ResultSet res 	=	pst.executeQuery();
			
			System.out.println(" \n     hotel name      "+
								"\n----------------------------");
			int i = 1;
			while (res.next()) {
				System.out.println(i+ ") " +res.getString(1));
				i++;
			}
			System.out.println("----------------------------");
			return res;	
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	
	//---------------------------------------------------------------------------------------
	//---------------------- Try to find client using a specifc prefix ----------------------
	//---------------------------------------------------------------------------------------
	public void searchClient(ResultSet rs, Integer number, String lname) {
		try {
			rs.absolute(number);			
			String hname = rs.getString(1);
			System.out.println("you choose: "+hname);
			
			PreparedStatement pstt 	=	conn.prepareStatement(
					"select p.lname, p.fname, p.\"idPerson\"\r\n"
					+ "from person p, hotel h, room r, roombooking rb \r\n"
					+ "where( h.name = ? and left(p.lname,1) = ? and r.\"idHotel\" = h.\"idHotel\" \r\n"
					+ "	  and r.\"idRoom\" = rb.\"roomID\" AND rb.\"bookedforpersonID\" = p.\"idPerson\" \r\n"
					+ "	  and p.\"idPerson\" not in(select \"idEmployee\" from employee))\r\n"
					+ "order by p.lname, p.fname;",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			// set the parameters
			pstt.setString(1, hname);
			pstt.setString(2, lname);
			
			// execute query and print results
			ResultSet ress = pstt.executeQuery();
			
			System.out.println(" \n     last name             		first name                 		idPerson"+
					"\n----------------------------------------------------------------------------------------");
			while (ress.next()) {
				System.out.println("     "+ress.getString(1) +"                 		"+ ress.getString(2) +"                   		"+ ress.getInt(3));
			}
			System.out.println("----------------------------------------------------------------------------------------");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//---------------------------------------------------------------------------------------
	//--------------------------- Try to find reservation details ---------------------------
	//---------------------------------------------------------------------------------------
	public void searchReservationDetailsPerClient(ResultSet rs, Integer number, Integer cid) {
		try {
			rs.absolute(number);			
			String hname = rs.getString(1);
						
			PreparedStatement pstt 	=	conn.prepareStatement(
					"with tmp as(\r\n"
					+ "SELECT distinct hb.idhotelbooking,rb.\"roomID\",rb.checkin ,rb.checkout,\r\n"
					+ "	rb.rate, hb.\"bookedbyclientID\" as idd\r\n"
					+ "FROM hotelbooking hb , client c , roombooking rb , room r, hotel h \r\n"
					+ "WHERE(hb.\"idhotelbooking\" = rb.\"hotelbookingID\" AND rb.\"roomID\" = r.\"idRoom\" \r\n"
					+ "      AND r.\"idHotel\" = h.\"idHotel\" AND h.name = ?)\r\n"
					+ "ORDER BY hb.\"idhotelbooking\")\r\n"
					+ "\r\n"
					+ "select t.idhotelbooking, t.\"roomID\",t.checkin ,t.checkout,t.rate\r\n"
					+ "from tmp t,client c\r\n"
					+ "where c.\"idClient\" = t.\"idd\" and c.\"idClient\" = ?",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			// set the parameters
			pstt.setString(1, hname);
			pstt.setInt(2, cid);
			
			// execute query and print results
			ResultSet ress = pstt.executeQuery();
			
			System.out.println(" \n     idhotelbooking        	roomID           checkin		 checkout		 rate"+
					"\n-------------------------------------------------------------------------------------------------------------------------");
			int i = 1;
			while (ress.next()) {
				System.out.println(i+")    	 "+ress.getString(1) +"  			  "+ ress.getString(2) +"  		"
						+ ress.getDate(3)+"   		 "+ ress.getDate(4)+"   		 "+ ress.getInt(5));
				i++;
			}
			System.out.println("-------------------------------------------------------------------------------------------------------------------------");
			StandardInputRead reader = new StandardInputRead();
			database db	= new database();
			
			db.printMenu3();
			loop: while (true) {
				
				int ch = reader.readPositiveInt("Select from above options: ");
				int resnum = reader.readPositiveInt("Choose reservation:  ");
				switch (ch){
					case 0: 
						break loop;
					case 1:	
						db.updateReservation(ress, ch, resnum);
						System.exit(0);
					case 2: 
						db.updateReservation(ress, ch, resnum);
						System.exit(0);
					case 3:	
						System.out.println("You choose to exit! Bye...");
						System.exit(0);
					default:
						continue;
				}
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	//---------------------------------------------------------------------------------------
	//---------------------------- Update Hotel and Room Booking ----------------------------
	//---------------------------------------------------------------------------------------
	@SuppressWarnings("resource")
	public void updateReservation(ResultSet rs, Integer choice, Integer reservation) {
		
		StandardInputRead reader = new StandardInputRead();
		try {
			rs.absolute(reservation);
			
			System.out.println("you choose:   " +reservation);
			
			Integer bookingid = rs.getInt(1);
			Integer roomid = rs.getInt(2);
			
			System.out.println("you choose:   " +bookingid);
			System.out.println("you choose:   " +roomid);
			
			if(choice == 1 ) {
				int price = reader.readPositiveInt("Enter new price: ");
				
				PreparedStatement pstq 	=	conn.prepareStatement(
						"update roombooking\r\n"
						+ "set rate = ?\r\n"
						+ "where \"hotelbookingID\" = ? and \"roomID\" = ?");
				
				// set the parameters
				pstq.setInt(1, price);
				pstq.setInt(2, bookingid);
				pstq.setInt(3, roomid);
				
				// execute query and print results
				pstq.executeUpdate();
				System.out.println("Update done!");
				
			}else if(choice == 2) {
				Date chin = (Date) reader.readDate("Enter new Checkin Date: ");
				Date chout = (Date) reader.readDate("Enter new Checkout Date: ");
				
				//---------------------------------------------- Checkin -----------------------------------------------
				PreparedStatement pstp 	=	conn.prepareStatement(
						"update roombooking\r\n"
						+ "set checkin = ?\r\n"
						+ "where \"hotelbookingID\" = ?");			
				// set the parameters
				pstp.setDate(1, chin);
				pstp.setInt(2, bookingid);
				// execute query and print results
				pstp.executeUpdate();
				System.out.println("Checkin update done!");
				
				//---------------------------------------------- Checkout ----------------------------------------------
				PreparedStatement psto 	=	conn.prepareStatement(
						"update roombooking\r\n"
						+ "set checkout = ?\r\n"
						+ "where \"hotelbookingID\" = ?");			
				// set the parameters
				psto.setDate(1, chout);
				psto.setInt(2, bookingid);
				// execute query and print results
				psto.executeUpdate();
				System.out.println("Checkout update done!");
				System.exit(0);
			}
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//---------------------------------------------------------------------------------------
	//----------------------------- Try to find Availables Rooms ----------------------------
	//---------------------------------------------------------------------------------------
	public void searchAvailableRooms(ResultSet rs, Integer number) {
		StandardInputRead reader = new StandardInputRead();
		try {
			rs.absolute(number);
			
			String hname = rs.getString(1);
			
			Date datein = (Date) reader.readDate("Enter Date-in: ");
			Date dateout = (Date) reader.readDate("Enter Date-out: ");
						
			PreparedStatement psta 	=	conn.prepareStatement(
					"SELECT DISTINCT r.\"number\" ,r.\"idRoom\", r.roomtype\r\n"
					+ "FROM room r, \"hotel\" h ,\"roombooking\" rb\r\n"
					+ "WHERE h.\"idHotel\"= r.\"idHotel\" AND h.name = ? AND r.\"idRoom\" = rb.\"roomID\" \r\n"
					+ "	AND rb.\"roomID\" NOT IN ( SELECT DISTINCT ro.\"idRoom\"\r\n"
					+ "               				 FROM hotel hot, room ro, roombooking rbo\r\n"
					+ "							 WHERE ro.\"idRoom\" = rbo.\"roomID\"\r\n"
					+ "                        			 AND (rbo.checkin <= ? AND rbo.checkout >= ?\r\n"
					+ "                        			 OR rbo.checkin <  ? AND rbo.checkout >= ?  \r\n"
					+ "									 OR ? <= rbo.checkin AND ? >= rbo.checkin))\r\n"
					+ "ORDER BY r.\"number\";",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			
			// set the parameters
			psta.setString(1, hname);
			psta.setDate(2, datein);
			psta.setDate(3, datein);
			psta.setDate(4, dateout);
			psta.setDate(5, dateout);
			psta.setDate(6, datein);
			psta.setDate(7, dateout);
			
			// execute query and print results
			ResultSet ress = psta.executeQuery();
			
			System.out.println(" \n     	number            		idRoom                     	roomtype"+
					"\n----------------------------------------------------------------------------------------");			
			int i = 1;
			while (ress.next()) {
				System.out.println(i+")	  "+ress.getInt(1) +"             		"+ ress.getInt(2) +"                     	"+ ress.getString(3));
				i++;
			}
			System.out.println("----------------------------------------------------------------------------------------");
			
			while(true) {
				int c = reader.readPositiveInt("If would you like to insert a new reservation enter 1 otherwise 0: ");
				if(c == 0) {
					System.out.println("You choose to exit! Bye...");
					System.exit(0);
				}else if(c==1) {
					int r = reader.readPositiveInt("Choose one from the available rooms: ");
					ress.absolute(r);					
					Integer roomid = ress.getInt(2);
					
					int id = reader.readPositiveInt("Enter client's ID: ");
					
					
					//---------------------------------------- INSERT HOTELBOOKING ----------------------------------------
					PreparedStatement pst1 	=	conn.prepareStatement(
							"INSERT INTO hotelbooking(\r\n"
							+ "	reservationdate, cancellationdate, \"bookedbyclientID\", payed, status)\r\n"
							+ "	VALUES (current_date, current_date+20 , ?, 'false', 'confirmed');");
					
					// set the parameters
					pst1.setInt(1, id);
					// execute query and print results
					pst1.executeUpdate();
					System.out.println("Hotel booking updated successfully!");
					
					//---------------------------------------- INSERT ROOMBOOKING ----------------------------------------
					PreparedStatement pst2 	=	conn.prepareStatement(
							"INSERT INTO roombooking(\r\n"
							+ "			\"hotelbookingID\", \"roomID\", \"bookedforpersonID\", checkin, checkout)\r\n"
							+ "			VALUES (?, ?, ?, ?, ?);");
					
					// set the parameters
					pst2.setInt(1, number);
					pst2.setInt(2, roomid);
					pst2.setInt(3, id);
					pst2.setDate(4, datein);
					pst2.setDate(5, dateout);
					// execute query and print results
					pst2.executeUpdate();
					System.out.println("Room booking updated successfully!");
					System.exit(0);
				}				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void printMenu() {
		System.out.println("\n==========================================\n");
		System.out.println("1) Connect to database.");
		System.out.println("2) Insert prefix in order to find the hotel.");
		System.out.println("\n==========================================");
	}
		
	public void printInsideMenu() {
		System.out.println("\n=====================================================\n");
		System.out.println("1) Search clients using thein last name as prefix.");
		System.out.println("2) Display room booking details of a specific client.");
		System.out.println("3) View available rooms for a period of time.");
		System.out.println("\n=====================================================");
	}
	
	public void printMenu3() {
		System.out.println("\n=====================================================\n");
		System.out.println("0) Select 0 if would you like to return at first menu.");
		System.out.println("1) Select 1 if would you like to update the price.");
		System.out.println("2) Select 2 if would you like to update  checkin / checkout.");
		System.out.println("3) Select 3 if would you like to exit.");
		System.out.println("\n=====================================================");
	}
	
	@SuppressWarnings("null")
	public static void main(String args[]) throws SQLException {
		int choice, insidechoice, num, clientid;
		String prefix, lnameprefix;
		String ip , dbName, user, passw;
		
		ResultSet rs=null;
		StandardInputRead reader = new StandardInputRead();
		LinkedList<Savepoint> savepoints = new LinkedList<Savepoint>();
		database db	=	new	database();
		
		while (true) {
			db.printMenu();
			choice = reader.readPositiveInt("Select from above options: ");
			
			switch (choice){
				case 1: 
					// read input data 
					//("jdbc:postgresql://localhost:5432", "db2021", "postgres", "61445239t")
					ip		=	reader.readString("Enter ip:  ");
					dbName	=	reader.readString("Enter database name:  ");
					user 	=	reader.readString("Enter user:  ");
					passw	=	reader.readString("Enter password:  ");
					ip = "localhost";
					dbName = "db2021";
					user = "postgres";
					passw = "61445239t";
					// connect
					db.establishConnection(ip, dbName, user, passw);
					db.CommitOnRequest(); //turn off the auto commit
					break;
					
				case 2:	
					prefix = reader.readString("Enter hotel's prefix:  ");
					rs = db.findHotelByPrefix(prefix);
					
					num = reader.readPositiveInt("Choose hotel:  ");

					// add savepoint
					savepoints.addLast(db.addSavepoint());
					
					loop1 : while (true) {
						db.printInsideMenu();
						insidechoice = reader.readPositiveInt("Select from above options: ");
						
						switch (insidechoice){
							case 1: 
								lnameprefix = reader.readString("Enter client's last name prefix:  ");
								// update but not commit
								db.searchClient(rs, num, lnameprefix);
								System.exit(0);
							case 2:					
								clientid = reader.readPositiveInt("Enter client's id: ");
								db.searchReservationDetailsPerClient(rs,num,clientid);
								break loop1;
							case 3:	
								db.searchAvailableRooms(rs,num);
								System.exit(0);						
							default:
								continue;
						}
					}
					//break;				
				default:
					continue;
			}
		}
	}
}
